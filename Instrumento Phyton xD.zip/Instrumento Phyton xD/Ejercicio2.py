nomb=input("Ingrese su nombre ")
print(f"Su nombre es: {nomb} ")

def nombre():

    j=0
    for i in nomb:
        print(i)
        i
        j=j+1
        print(j)
        pass

    print(f"El número de letras de su nombre es: {j}")
 
    return nomb

numeroletras=nombre()
print(numeroletras)








