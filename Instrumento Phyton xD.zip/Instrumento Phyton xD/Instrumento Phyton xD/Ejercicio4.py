print("Hola, Bienvenido")
question=0
datos={}

def registro():
    name=input("Ingrese su nombre ")
    apelli=input("Ingrese su apellido ")
    old=int(input("Ingrese su edad "))
    weight=int(input("Ingrese su peso "))
    altura=float(input("Ingrese su estatura "))
    usuario=dict(nombre=name,apellidos=apelli,edad=old,peso=weight,estatura=altura)
    return usuario

pregunta=1

while pregunta==1:

    question=int(input("Digite 1 si desea hacer un registro \nDigite 2 si quiere consultar sus documentos \n"))
    if question==1:
        documento=input("Ingrese su documento ")
        datos[documento]=registro()
        print("Registro existoso \n")  
    if question==2:
        documento=input("Ingrese el documento a consultar ") 
        print(datos[documento])     
    pregunta=int(input("Ingrese 1 para mostrar el menú "))
    

