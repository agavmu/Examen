numeros= [1,2,3,4,5,6,7,8,9,10]

for i in numeros:
    print(i)
    pass

j=0

while j < len(numeros):
    print(numeros[j])
    j=j+1
    pass