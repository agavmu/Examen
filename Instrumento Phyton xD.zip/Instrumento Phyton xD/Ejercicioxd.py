
n1=int(input("Ingrese el número 1 "))
print(f"El número A fue: {n1}")



n2=int(input("Ingrese el número 2 "))
print(f"El número B fue: {n2}")



def numeros(n1,n2):
    
    if (n1>n2):
        print(f"El número {n1} es mayor que número {n2}")
    else:
        print(f"El número {n2} es mayor que número {n1}")

    return numeros

num=numeros (n1,n2)
print(num)

