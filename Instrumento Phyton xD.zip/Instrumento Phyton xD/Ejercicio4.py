print("Hola, Bienvenido")
question=0
question=int(input("Digite 1 si desea hacer un registro "))
datos={"documento":23, "nombre":"andres", "apellidos":"villamil", "edad":2, "peso":3, "estatura":1.76}
while question==1:
    
    datos["documento"]=input("Ingrese su documento ")
    print(f"Su documento es: {'documento'}\n")

    datos["nombre"]=input("Ingrese su nombre ")
    print(f"El nombre ingresado es: {'nombre'}\n")

    datos["apellidos"]=input("Ingrese sus apellidos ")
    print(f"Sus apellidos ingresados son: {'apellidos'}\n")

    datos["edad"]=int(input("Ingrese su edad "))
    print(f"Su edad es de: {'edad'}\n")

    datos["peso"]=int(input("Ingrese su peso "))
    print(f"Su peso es de: {'peso'}\n")

    datos["estatura"]=float(input("Ingrese su estatura "))
    print(f"Su estatura es de: {'estatura'}\n")

    print("Registro existoso \n")

    datosIngresados=(f"Documento: {'documento'}, Nombre: {'nombre'}, Apellidos: {'apellidos'}, Edad: {'edad'}, Peso: {'peso'}, Estatura: {'estatura'}")

    consulta=int(input("Ingrese el numero de documento para ver su registro \n"))

    if(consulta=='documento'):
        print(datos['documento'] + f"\n")
    
    question =int(input("Digite 1 si desea hacer un nuevo registro\nEn caso contrario ingrese cualguier digito \n"))
    pass

